package com.example.proyectom.ui.gallery;

import android.content.DialogInterface;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import com.example.proyectom.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import modelos.Descripcion;

public class GalleryFragment extends Fragment {
    /////////////////////////////////////////////////////////////////////////////
    public static ArrayList<Descripcion> listaPiezas=new ArrayList<>();
    ////////////////////////////////////////////////////////////////////////////////
    TableRow.LayoutParams layoutfila=new TableRow.LayoutParams(TableRow.LayoutParams.WRAP_CONTENT, TableRow.LayoutParams.WRAP_CONTENT);
    TableRow.LayoutParams layoutdescripcion=new TableRow.LayoutParams(TableRow.LayoutParams.WRAP_CONTENT, TableRow.LayoutParams.WRAP_CONTENT);
    TableRow.LayoutParams layoutlargo=new TableRow.LayoutParams(TableRow.LayoutParams.WRAP_CONTENT, TableRow.LayoutParams.WRAP_CONTENT);
    TableRow.LayoutParams layoutancho=new TableRow.LayoutParams(TableRow.LayoutParams.WRAP_CONTENT, TableRow.LayoutParams.WRAP_CONTENT);
    TableRow.LayoutParams layoutgrueso=new TableRow.LayoutParams(TableRow.LayoutParams.WRAP_CONTENT, TableRow.LayoutParams.WRAP_CONTENT);
    TableRow.LayoutParams layoutcantidad=new TableRow.LayoutParams(TableRow.LayoutParams.WRAP_CONTENT, TableRow.LayoutParams.WRAP_CONTENT);
    TableRow.LayoutParams layoutpies=new TableRow.LayoutParams(TableRow.LayoutParams.WRAP_CONTENT, TableRow.LayoutParams.WRAP_CONTENT);
    ///////////////////////////////////////////////////////////////////////////////////////
    EditText edtId, edtLargo, edtAncho, edtGrueso, edtCantidad;
    Spinner spinDescripcion;
    Button btnAgregar;
    TableLayout tablaPieza;
    TableRow fila;
    TextView tv_Descripcion, tv_largo, tv_ancho, tv_grueso, tv_cantidad, tv_pies, tvSumaPies, tvNombre;
    String id;
    RequestQueue requestQueue;

    double total_pies=0;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_gallery, container, false);
        cargarControles(root);
        cargaEventos();
        CargarLista();
        alerta2();
        return root;
    }
    private void alerta2() {
        AlertDialog.Builder alert2=new AlertDialog.Builder(getActivity());
        final EditText input = new EditText(getActivity());
        alert2.setTitle("Cotizar")
                .setMessage("Por favor ingresa el id del mueble")
                .setView(input)
                .setPositiveButton("Acceder", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        id=input.getText().toString();
                        buscarMueble("http://192.168.0.22/ControlProyectoBD/buscar_mueble.php?id_Mueble="+id);
                    }
                })
                .create().show();
    }
    private void buscarMueble(String URL){
        JsonArrayRequest jsonArrayRequest=new JsonArrayRequest(URL, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                JSONObject jsonObject = null;
                for (int i = 0; i < response.length(); i++) {
                    try {
                        jsonObject = response.getJSONObject(i);
                        edtId.setText(jsonObject.getString("id_Mueble"));
                        tvNombre.setText(jsonObject.getString("Nombre"));
                    } catch (JSONException e) {
                        Toast.makeText(getActivity(), e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getActivity(),"Error de Conexion",Toast.LENGTH_SHORT).show();
            }
        });
        requestQueue= Volley.newRequestQueue(getActivity());
        requestQueue.add(jsonArrayRequest);
    }

    private void cargaEventos() {
        btnAgregar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                agregarPieza();
            }
        });
    }

    private void agregarPieza() {
        double largo100, ancho100, grueso100, volumenM3_1, volumenM3_2, pies;
        double constante=0.00236;

        if(!edtLargo.getText().toString().isEmpty() &&
            !edtAncho.getText().toString().isEmpty() &&
            !edtGrueso.getText().toString().isEmpty() &&
            !edtCantidad.getText().toString().isEmpty() &&
            !spinDescripcion.getSelectedItem().toString().equals("Descripcion")){
            String descripcion = spinDescripcion.getSelectedItem().toString();
            double largo = Double.parseDouble(edtLargo.getText().toString());
            double ancho = Double.parseDouble(edtAncho.getText().toString());
            double grueso = Double.parseDouble(edtGrueso.getText().toString());
            int cantidad = Integer.parseInt(edtCantidad.getText().toString());
            largo100=largo/100;
            ancho100=ancho/100;
            grueso100=grueso/100;
            volumenM3_1=largo100*ancho100*grueso100;
            volumenM3_2=cantidad*volumenM3_1;
            pies=volumenM3_2/constante;
            Descripcion pieza = new Descripcion(descripcion,largo,ancho,grueso,cantidad,pies);
            listaPiezas.add(pieza);
            total_pies = total_pies + pies;
            tvSumaPies.setText(String.valueOf(total_pies));
            Agregar(descripcion,largo,ancho,grueso,cantidad,pies);
            Limpiar();
        }else{
            Toast.makeText(getActivity(), "Llena todos los campos", Toast.LENGTH_SHORT).show();
        }



    }

    private void Limpiar() {
        edtLargo.setText("");
        edtAncho.setText("");
        edtGrueso.setText("");
        edtCantidad.setText("");
        spinDescripcion.setSelection(0);
    }

    private void Agregar(String descripcion, double largo, double ancho, double grueso, int cantidad, double pies) {
        fila = new TableRow(getActivity());
        fila.setLayoutParams(layoutfila);

        tv_Descripcion = new TextView(getActivity());
        tv_Descripcion.setText(descripcion);
        tv_Descripcion.setPadding(10,10,10,10);
        tv_Descripcion.setLayoutParams(layoutdescripcion);
        fila.addView(tv_Descripcion);

        tv_largo = new TextView(getActivity());
        tv_largo.setText(String.valueOf(largo));
        tv_largo.setPadding(10,10,10,10);
        tv_largo.setLayoutParams(layoutlargo);
        fila.addView(tv_largo);

        tv_ancho = new TextView(getActivity());
        tv_ancho.setText(String.valueOf(ancho));
        tv_ancho.setPadding(10,10,10,10);
        tv_ancho.setLayoutParams(layoutancho);
        fila.addView(tv_ancho);

        tv_grueso = new TextView(getActivity());
        tv_grueso.setText(String.valueOf(grueso));
        tv_grueso.setPadding(10,10,10,10);
        tv_grueso.setLayoutParams(layoutgrueso);
        fila.addView(tv_grueso);

        tv_cantidad = new TextView(getActivity());
        tv_cantidad.setText(String.valueOf(cantidad));
        tv_cantidad.setPadding(10,10,10,10);
        tv_cantidad.setLayoutParams(layoutcantidad);
        fila.addView(tv_cantidad);

        tv_pies = new TextView(getActivity());
        tv_pies.setText(String.valueOf(pies));
        tv_pies.setPadding(10,10,10,10);
        tv_pies.setLayoutParams(layoutpies);
        fila.addView(tv_pies);

        tablaPieza.addView(fila);
    }

    private void CargarLista() {

        fila = new TableRow(getActivity());
            fila.setLayoutParams(layoutfila);

                tv_Descripcion = new TextView(getActivity());
                tv_Descripcion.setText("Descripcion");
                tv_Descripcion.setGravity(Gravity.CENTER);
                tv_Descripcion.setBackgroundColor(Color.BLACK);
                tv_Descripcion.setTextColor(Color.WHITE);
                tv_Descripcion.setPadding(10,10,10,10);
                tv_Descripcion.setLayoutParams(layoutdescripcion);
                fila.addView(tv_Descripcion);

                tv_largo = new TextView(getActivity());
                tv_largo.setText("Largo");
                tv_largo.setGravity(Gravity.CENTER);
                tv_largo.setBackgroundColor(Color.BLACK);
                tv_largo.setTextColor(Color.WHITE);
                tv_largo.setPadding(10,10,10,10);
                tv_largo.setLayoutParams(layoutlargo);
                fila.addView(tv_largo);

                tv_ancho = new TextView(getActivity());
                tv_ancho.setText("Ancho");
                tv_ancho.setGravity(Gravity.CENTER);
                tv_ancho.setBackgroundColor(Color.BLACK);
                tv_ancho.setTextColor(Color.WHITE);
                tv_ancho.setPadding(10,10,10,10);
                tv_ancho.setLayoutParams(layoutancho);
                fila.addView(tv_ancho);

                tv_grueso = new TextView(getActivity());
                tv_grueso.setText("Grueso");
                tv_grueso.setGravity(Gravity.CENTER);
                tv_grueso.setBackgroundColor(Color.BLACK);
                tv_grueso.setTextColor(Color.WHITE);
                tv_grueso.setPadding(10,10,10,10);
                tv_grueso.setLayoutParams(layoutgrueso);
                fila.addView(tv_grueso);

                tv_cantidad = new TextView(getActivity());
                tv_cantidad.setText("Cantidad");
                tv_cantidad.setGravity(Gravity.CENTER);
                tv_cantidad.setBackgroundColor(Color.BLACK);
                tv_cantidad.setTextColor(Color.WHITE);
                tv_cantidad.setPadding(10,10,10,10);
                tv_cantidad.setLayoutParams(layoutcantidad);
                fila.addView(tv_cantidad);

                tv_pies = new TextView(getActivity());
                tv_pies.setText("Pies");
                tv_pies.setGravity(Gravity.CENTER);
                tv_pies.setBackgroundColor(Color.BLACK);
                tv_pies.setTextColor(Color.WHITE);
                tv_pies.setPadding(10,10,10,10);
                tv_pies.setLayoutParams(layoutpies);
                fila.addView(tv_pies);

                tablaPieza.addView(fila);


            }



    private void cargarControles(View root) {
        edtId = root.findViewById(R.id.co_edt_id);
        tvNombre = root.findViewById(R.id.co_tv_Nombre);
        spinDescripcion = root.findViewById(R.id.co_spin_descripcion);
        edtLargo = root.findViewById(R.id.co_edt_tex_largo);
        edtAncho = root.findViewById(R.id.co_edt_tex_ancho);
        edtGrueso = root.findViewById(R.id.co_edt_tex_Grueso);
        edtCantidad = root.findViewById(R.id.co_edt_tex_cantidad);
        btnAgregar = root.findViewById(R.id.co_btn_Agregar);
        tablaPieza = root.findViewById(R.id.tab_pies);
        tvSumaPies = root.findViewById(R.id.co_tv_total_pies);


    }

}